const util = require('../../utils/util');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    test1: "hhh",

  },

  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },

  Click: function () {
    var page = this;
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/logindata',
        success:function(res){
        console.log(res.data)
        var temp=res.data.data[0].name;   
        page.setData({ 
          test1: temp 
          })
      } 
    })
    },

 Click2: function () {
   var that = this; 
wx.request({
  url: 'https://npswk7eu.qcloud.la/weapp/search',
    data:
    {
      name: 'aaaaaaa',
       sex: 'male',
       ID: 111111
      
    },
   
    success: function (res) {
       console.log(res.data);
      //  console.log('submit success~');
      // that.modalTap();
    },
    fail: function (res) {
      console.log('submit fail~');
    },
    // complete: function (res) {
    //   console.log('submit complete~');
    //   console.log(formData)
    // }
  })
}, 

 Click3: function () {
   var page = this;
   wx.request({
     url: 'https://npswk7eu.qcloud.la/weapp/search',
    //  success: function (res) {
    //       console.log(res.data)
    //      var temp = res.data.data[0].name;
    //      page.setData({
    //        test1: temp
    //      })
    //  }
   })
 },
 
})
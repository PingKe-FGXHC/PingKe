
const util = require('../../utils/util');

Page({

  data: {
    searchName:null,
    // items: [
    //   {
    //     // "url": "http://127.0.0.1/1.flv",
    //     "title": "这是标题一"
    //   },
    //   {
    //     "url": "http://127.0.0.1/2.flv",
    //     "title": "这是标题二"
    //   }
    // ]
    items:[{}],

  },


  navigateToComment: function (e) {
    var self = this;
    var index = e.currentTarget.id;
    // console.log(index);
    var courseInform = {course:self.data.items[index].course, teacher:self.data.items[index].teacher}
    // console.log(courseInform);
    self.setData({
      isBtnClicked: true
    });
    wx.navigateTo({
      url: '../comment/comment?courseInform=' + courseInform
    })
    setTimeout(function () {
      self.setData({
        isBtnClicked: false
      });
    }, 1000);
  },

  navigateToReport: function (e) {
    var self = this;
    var index = e.currentTarget.id;
    // console.log(index);
    var courseInform = { course: self.data.items[index].course, teacher: self.data.items[index].teacher }
    // console.log(courseInform);
    if (!self.data.isBtnClicked) {
      wx.navigateTo({
        url: '../report/report?courseInform=' + courseInform
      })
    }

  },

  onLoad:function(options){
    var self = this;
    this.setData({
      searchName:options.searchName,
    })

    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/search',

      data: {
        searchName: this.data.searchName,
      },
      success: function (res) {

        console.log(res.data)
       if(res.data.data.length==0){  //失败
         util.showModel('查询失败', '无此课程');
       }
      else{  //成功
        // item = self.data.item, index = 10;//n随意
        // item[index] = changedata;
        var i;
        self.setData({
          items : res.data.data
        })
        
      }
      }  
    })
  }
})
const Koa = require('koa')
const app = new Koa()
const debug = require('debug')('koa-weapp-demo')
const response = require('./middlewares/response')
const bodyParser = require('koa-bodyparser')
const config = require('./config')

// App({
//   globalData: {
//     name: 's',
//     sex: 'fa',
//     ID: 0
//   }

// })

// 使用响应处理中间件
 app.use(response)

// // 解析请求体
 app.use(bodyParser())

// app.use(async (ctx) => {
//   let url = ctx.url;
//   // 从上下文中直接获取
//   let ctx_query = ctx.query;
//   let ctx_querystring = ctx.querystring;

//   // 从ctx.request中获取
//   let request = ctx.request;
//   let req_query = request.query;
//   let req_querystring = request.querystring;

//   ctx.body = {
//     url,
//     ctx_query,
//     ctx_querystring,
//     req_query,
//     req_querystring
//   }

//   // app.global.data.name =ctx_query.name;


// });


// 引入路由分发
const router = require('./routes')
app.use(router.routes())

// 启动程序，监听端口
app.listen(config.port, () => debug(`listening on port ${config.port}`))



const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var person = {
    username: ctx.query.username,   
    password: ctx.query.password,       
     
  }
  // var person = {
  //   name: ctx.query.name,   // ctx.request.body.name,
  //   sex: ctx.query.sex,       // ctx.request.body.sex,
  //   ID: ctx.query.ID,   //ctx.request.body.ID,
  // }
  await mysql('User').insert(person)

}
const { mysql } = require('../qcloud')

module.exports = async ctx => {
  
  var temp={
    course: ctx.query.inputclass,

  }
  var res = await mysql("trendingcourses").where('course','=',temp.course)
  ctx.state.data  =  res
}


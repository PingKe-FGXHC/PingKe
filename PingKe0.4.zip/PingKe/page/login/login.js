const util=require('../../utils/util');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    password:null,
    username:null
  },

  getUsername: function (e) {
    this.setData({
      username: e.detail.value
    })
  },
  getPassword: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  loginClick: function (e) {
    app.globalData.userInfo = { username: this.data.username, password: this.data.password }
    if (app.globalData.userInfo.username == 'admin' && app.globalData.userInfo.password == 'admin') {
      util.showSuccess('登录成功');
      wx.redirectTo({
        url: '../home/home',    
      })
    }/*
    else if (app.globalData.userInfo.username != 'admin' ){
      
          var that = this;
          var formData = e.detail.value.id; //获取表单所有name=id的值  
          wx.request({
            url: 'http://localhost/2018-5-24/search.php?id=' + formData,
            data: formData,
            header: { 'Content-Type': 'application/json' },
            success: function (res) {
              console.log(res.data)
              that.setData({
                re: res.data,
              })
              wx.showToast({
                title: '已提交',
                icon: 'success',
                duration: 2000
              })
            }
          })
        }*/
    else {
      util.showModel('登录失败','账户或密码错误');
      this.setData({
        username: app.globalData.userInfo.username,
       
      })
    } 
  }
})
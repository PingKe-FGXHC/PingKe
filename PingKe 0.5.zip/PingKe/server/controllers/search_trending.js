const { mysql } = require('../qcloud')



module.exports = async ctx => {
  var res = await mysql('trendingcourses').orderBy('rating', 'desc')
   ctx.state.data  =  res
}


// knex('users').orderBy('name', 'desc')
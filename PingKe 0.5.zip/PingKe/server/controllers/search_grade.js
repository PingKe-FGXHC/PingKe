const { mysql } = require('../qcloud')

module.exports = async ctx => {

  var temp = {
    course: ctx.query.CourseName,
    teacher: ctx.query.TeacherName,
    grade_total: ctx.query.grade_total

  }
  // var resSearchGrade = await mysql("mark").where('course', '=', temp.course).andWhere('teacher', '=', temp.teacher)
  // var resSearchGrade = await mysql('mark').where('course', '=', 'dota2教程')
  // var resSearchGrade = mysql('mark').where('course', '=', 'dota2教程')
  var resSearchGrade = await mysql('mark').where({ course: ctx.query.CourseName, teacher: ctx.query.TeacherName})
  // await mysql('trendingcourses').where({ course: temp.course }).update({rating: temp.grade_total})


  ctx.state.data = resSearchGrade
}


const { mysql } = require('../qcloud')

module.exports = async ctx => {
  
  var temp={
    course: ctx.query.searchName,

  }
  var resSearchName = await mysql("trendingcourses").where('course','=',temp.course)
  ctx.state.data = resSearchName
}


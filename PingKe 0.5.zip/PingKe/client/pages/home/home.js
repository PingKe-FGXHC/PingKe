
// 引入coolsite360交互配置设定
//require('coolsite.config.js');
const util = require('../../utils/util');
// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "home",
  /**
   * 页面的初始数据
   */

  data: {
    trendingCourse1: "",
    trendingTeacher1: "",
    trendingCourse2: "",
    trendingTeacher2: "",
    trendingCourse3: "",
    trendingTeacher3: "",
    trendingCourse4: "",
    trendingTeacher4: "",
    trendingCourse5: "",
    trendingTeacher5: "",
    inputName:null,
    rank:null,
    courseName:null,
    teacherName:null,
    Course:null,
    Teacher:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
 
  onLoad() {
    // 注册coolsite360交互模块
    // app.coolsite360.register(this);
    var that = this;
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/search_trending',

      success: function (res) {
        var user = res.data.data;
        console.log(res);

        // that.setData({ user: user });
        that.setData({ trendingCourse1: user[0].course });
        that.setData({ trendingTeacher1: user[0].teacher });
        that.setData({ trendingCourse2: user[1].course });
        that.setData({ trendingTeacher2: user[1].teacher });
        that.setData({ trendingCourse3: user[2].course });
        that.setData({ trendingTeacher3: user[2].teacher });
        that.setData({ trendingCourse4: user[3].course });
        that.setData({ trendingTeacher4: user[3].teacher });
        that.setData({ trendingCourse5: user[4].course });
        that.setData({ trendingTeacher5: user[4].teacher });

      }
    })
  }, 


  onReady () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  /*onShow () {
    // 执行coolsite360交互组件展示
    app.coolsite360.onShow(this);
  },*/

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh () {
    
  },


  //以下为自定义点击事件
  bindSearchName:function(e){
    this.setData({
      inputName:e.detail.value,
    })

  },
  // navigateToResult: function () {
  
  //   wx.request({
  //     url: 'https://npswk7eu.qcloud.la/weapp/search',

  //     data: {
  //       inputclass: this.data.inputName,
  //     },
  //     success: function (res) {
  //      if(res.data.data.length==0){
  //        util.showModel('查询失败', '无此课程');
  //      }
  //     else{
  //       console.log(res.data.data[0].course)
  //      wx.navigateTo({
  //        url: '../list/list?searchName=' + this.data.inputName,
  //      })
  //     }
  //     }  
  //   })
  // },

  

  navigateToResult: function () {
    wx.redirectTo({
         url: '../list/list?searchName=' + this.data.inputName,
       })
  },

})


const util=require('../../utils/util');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    password:null,
    username:null
  },

  getUsername: function (e) {
    this.setData({
      username: e.detail.value
    })
  },
  getPassword: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  RegistClick: function (){
    wx.navigateTo({
      url: '../register/register',
    })
  },
  loginClick: function (e) {
    app.globalData.username = this.data.username;
    if (this.data.username == 'admin' && this.data.password  == 'admin') {
      util.showSuccess('登录成功');
      wx.redirectTo({
        url: '../home/home',    
      })
    }
    else if (this.data.username != 'admin' ){
          var that = this;
          wx.request({
            url: 'https://npswk7eu.qcloud.la/weapp/logindata',
             data:
             {
               username: this.data.username
             },
       
            success: function (res) {
              var temp = res.data.data[0];
              if (res.data.data.length == 0) {
                util.showModel('登录失败', '账户或密码错误');
              }  
              else if (temp.password == that.data.password){
                util.showSuccess('登录成功');
                wx.redirectTo({
                  url: '../home/home',
                })
                }
              else{
                util.showModel('登录失败', '账户或密码错误');
                }

            },
              fail: function (res) {
                util.showModel('登录失败', '账户或密码错误');
              }
          })
    }
    else {
      util.showModel('登录失败','账户或密码错误');
      }
    } 
})
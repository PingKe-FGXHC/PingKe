const util = require('../../utils/util');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: { 
    username: null,
    password: null,
    password2: null,
  },

  getUsername: function (e) {
    this.setData({
      username: e.detail.value
    })
  },
  getPassword: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  getPassword2: function (e) {
    this.setData({
      password2: e.detail.value
    })
  },

  regist: function (e) {
    if (this.data.username==null||this.data.password==null||this.data.password2==null){
      util.showModel('注册失败', '请正确填写注册数据');
    }
    else if (this.data.password!=this.data.password2){
    util.showModel('注册失败', '请输入两次相同的密码');}
    
    else{
     
      wx.request({
        url: 'https://npswk7eu.qcloud.la/weapp/register',
        data:
        {
          username: this.data.username,
          password: this.data.password,
          name: this.data.username,
          sex: this.data.password,
          ID :15141
        },
        success: function (res) {
          if(res.data.code==0){
          util.showSuccess('注册成功');
          wx.redirectTo({
            url: '../login/login',
          })}
          else{ 
            util.showModel('注册失败', '该用户名已被注册')
          }
        },
        fail: function (res) {
          console.log('submit fail~');
        },
      })
      
    }

   
   
    /*
    else if (app.globalData.userInfo.username != 'admin' ){
      
          var that = this;
          var formData = e.detail.value.id; //获取表单所有name=id的值  
          wx.request({
            url: 'http://localhost/2018-5-24/search.php?id=' + formData,
            data: formData,
            header: { 'Content-Type': 'application/json' },
            success: function (res) {
              console.log(res.data)
              that.setData({
                re: res.data,
              })
              wx.showToast({
                title: '已提交',
                icon: 'success',
                duration: 2000
              })
            }
          })
        }*/
   
  }
})
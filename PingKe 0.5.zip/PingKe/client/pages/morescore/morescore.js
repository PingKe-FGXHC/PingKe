
// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "morescore",

  /**
   * 页面的初始数据
   */

  data: {
    aspect1: '授课态度',
    grade1: null,
    aspect2: '答疑水平',
    grade2: null,
    aspect3: '课堂互动',
    grade3: null,
    aspect4: '给分情况',
    grade4: null,
    aspect5: '授课水平',
    grade5: null,
    grade_total: null,
    count:null,
    total: '综合评分',
    totalscore: '25',
    CourseName: null,
    TeacherName: null,
    // searchCourse:null,
    // searchTeacher:null




  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var self=this;
    this.setData({
      CourseName: options.CourseName,
      TeacherName: options.TeacherName,
    })

    console.log(this.data.CourseName)
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/search_grade',

      data: {
        CourseName: this.data.CourseName,
        TeacherName: this.data.TeacherName,
        grade_total:this.data.grade_total
      },
      
      success: function (resSearchGrade) {
        console.log(resSearchGrade.data.data.length)
        if (resSearchGrade.data.data.length == 0) {  //失败
          util.showModel('查询失败', '暂无人评价');
        }
        else {  //成功
          console.log(resSearchGrade.data.data[0])
          self.setData({
            grade1: (resSearchGrade.data.data[0].grade1/(resSearchGrade.data.data[0].count)).toFixed(2),
            grade2: (resSearchGrade.data.data[0].grade2 / (resSearchGrade.data.data[0].count)).toFixed(2),
            grade3: (resSearchGrade.data.data[0].grade3 / (resSearchGrade.data.data[0].count)).toFixed(2),
            grade4: (resSearchGrade.data.data[0].grade4 / (resSearchGrade.data.data[0].count)).toFixed(2),
            grade5: (resSearchGrade.data.data[0].grade5 / (resSearchGrade.data.data[0].count)).toFixed(2),
            grade_total: ((resSearchGrade.data.data[0].grade_total) / (resSearchGrade.data.data[0].count)).toFixed(2)
          })

        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  /*onShow () {
    // 执行coolsite360交互组件展示
    app.coolsite360.onShow(this);
  },*/

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },


  //以下为自定义点击事件

})


const { mysql } = require('../qcloud')

module.exports = async ctx => {

  var res = await mysql("trendingcourses").select('*')
  ctx.state.data=res

}

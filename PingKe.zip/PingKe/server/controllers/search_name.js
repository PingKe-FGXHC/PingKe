const { mysql } = require('../qcloud')

module.exports = async ctx => {

  var resSearchName = await mysql("trendingcourses").where('course', '=', ctx.query.searchName).or.where('teacher', '=', ctx.query.searchName, ).or.where('course', 'like', '%' + ctx.query.searchName + '%').or.where('teacher', 'like', '%' + ctx.query.searchName + '%')
  ctx.state.data = resSearchName
}


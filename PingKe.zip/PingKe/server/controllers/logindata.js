const  {  mysql  }  =  require('../qcloud')

module.exports  =  async ctx  =>  {
  var phy = {
    username: ctx.query.username,   // ctx.request.body.name,
  }
  var  res  =  await  mysql('User').where('username','=',phy.username)
  ctx.state.data = res}


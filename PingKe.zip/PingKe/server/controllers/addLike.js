const { mysql } = require('../qcloud')

module.exports = async ctx => {

  // var temp = {
  //   course: ctx.query.CourseName,
  //   teacher: tx.query.TeacherName,
  //   username: ctx.query.UserName,
  // }
  //执行加一操作
  await mysql('comment').where({ course: ctx.query.CourseName, teacher: ctx.query.TeacherName, username: ctx.query.UserName}).increment('thumbsup',1)
  var res = await (mysql("comment").orderBy('thumbsup', 'desc')).where({ course: ctx.query.CourseName, teacher: ctx.query.TeacherName })
   ctx.state.data = res
}
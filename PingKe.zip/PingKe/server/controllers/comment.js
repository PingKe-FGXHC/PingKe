const { mysql } = require('../qcloud')

module.exports = async ctx => {

  var comment = {
    username: ctx.query.username,
    thumbsup: 0,
    comment: ctx.query.comment,
    course: ctx.query.course,
    teacher: ctx.query.teacher,
  }
  
  var res = await mysql('comment').where('username', '=', ctx.query.username);
  ctx.state.data  =  res;
  await mysql('comment').insert(comment);
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('count', 1)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade1', ctx.query.grade1)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade2', ctx.query.grade2)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade3', ctx.query.grade3)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade4', ctx.query.grade4)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade5', ctx.query.grade5)
  await mysql('mark').where({ course: ctx.query.course, teacher: ctx.query.teacher }).increment('grade_total', ctx.query.grade_total)

}

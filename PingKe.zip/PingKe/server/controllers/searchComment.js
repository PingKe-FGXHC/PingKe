const { mysql } = require('../qcloud')

module.exports = async ctx => {

  var temp = {
    course: ctx.query.CourseName,
    teacher: ctx.query.TeacherName,
    

  }
  
  var res = await (mysql("comment").orderBy('thumbsup', 'desc')).where({ course: temp.course, teacher: temp.teacher })
  // ('course', '=', temp.course, 'and', 'teacher', '=', temp.teacher) 
  // where('course', '=', temp.course) 
  ctx.state.data = res
}


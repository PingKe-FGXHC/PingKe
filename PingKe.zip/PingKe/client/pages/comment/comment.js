const util = require('../../utils/util');
// 引入coolsite360交互配置设定
//require('coolsite.config.js');

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "comment",
  /**
   * 页面的初始数据
   */

  data: {
    username: "",
    gradeValue: null,
    coursename: "",
    teachername: "",
    grade1: null,
    grade2: null,
    grade3: null,
    grade4: null,
    grade5: null,
    comment: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 注册coolsite360交互模块
    this.setData({
      username: app.globalData.username,
      coursename: options.coursename,
      teachername: options.teachername
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  /*onShow () {
    // 执行coolsite360交互组件展示
    app.coolsite360.onShow(this);
  },*/

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  getcomment: function (e) {
    this.setData({
      comment: e.detail.value
    })
  },

  //以下为自定义点击事件
  grade: function (e) {
    this.setData({
      gradeValue: e.detail.value
    })
  },

  radioChange1: function (e) {
    this.setData({
      grade1: e.detail.value
    })

  },
  radioChange2: function (e) {
    this.setData({
      grade2: e.detail.value
    })

  },
  radioChange3: function (e) {
    this.setData({
      grade3: e.detail.value
    })

  },
  radioChange4: function (e) {
    this.setData({
      grade4: e.detail.value
    })

  },
  radioChange5: function (e) {
    this.setData({
      grade5: e.detail.value
    })

  },

  gradeSubmit: function () {
    var that = this;
    if (this.data.grade1 == null || this.data.grade2 == null || this.data.grade3 == null || this.data.grade4 == null || this.data.grade5 == null) {
      util.showModel('提交失败', '请填写完课程评分');
    }
    else{
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/comment',
      data:
      {
        username: this.data.username,
        course: this.data.coursename,
        teacher: this.data.teachername,
        grade1: parseFloat(this.data.grade1),
        grade2: parseFloat(this.data.grade2),
        grade3: parseFloat(this.data.grade3),
        grade4: parseFloat(this.data.grade4),
        grade5: parseFloat(this.data.grade5),
        grade_total: parseFloat(this.data.grade1) + parseFloat(this.data.grade2) + parseFloat(this.data.grade3) + parseFloat(this.data.grade4) + parseFloat(this.data.grade5),
        comment: this.data.comment

      },
      success: function (res) {
        if(res.data.code==0){
          util.showSuccess('提交成功');
        }
        else if (res.data.code == -1) {
          util.showModel('提交失败', '请勿重复提交评分');
        }
        setTimeout(function () {
        wx.redirectTo({
          url: '../home/home',
        })
        },1500);
     
      }


    })
    }
  }

})

 //       else if (temp.password == that.data.password) {
  //         util.showSuccess('登录成功');
  //         wx.redirectTo({
  //           url: '../home/home',
  //         })
  //       }
  //       else {
  //         util.showModel('登录失败', '账户或密码错误');
  //       }

  //     },
  //   })
  // },


// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "report",
  
  /**
   * 页面的初始数据
   */

  data: {
    courseInform:null,
    Course:null,
    Teacher:null,

    // trendingCourse1:null,
    // trendingTeacher1:null,
    // trendingCourse2: null,
    // trendingTeacher2: null,
    // trendingCourse3: null,
    // trendingTeacher3: null,
    // trendingCourse4: null,
    // trendingTeacher4: null,
    // trendingCourse5: null,
    // trendingTeacher5: null,

    // comment1:"",
    // comment2: "",
    // comment3: "",
    // like1:0,
    // like2:0,
    // like3:0,
    items:[{}],
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  // onLoad: function (options) {
  //   var self = this;
  //   console.log(options.courseName);
  //   this.setData({
  //     Course: options.courseName,
  //     Teacher: options.teacherName,
  //   })

  //   wx.request({
  //     url: 'https://npswk7eu.qcloud.la/weapp/searchComment',

  //     data: {
  //       teacherName: this.data.Teacher,
  //       courseName: this.data.Course,
  //     },
  //     success: function (res) {
  //       // console.log(res.data)
  //       self.setData({
  //         items: res.data.data,
  //         // comment1: res.data.data[0].comment,
  //         // comment1: res.data.data[1].comment,
  //         // comment1: res.data.data[2].comment,
  //         // like1: res.data.data[0].like,
  //         // like1: res.data.data[1].like,
  //         // like1: res.data.data[2].like,
  //       })
  //     }
  //   })
  // },

  onLoad: function (options) {
    var self = this;
    console.log(options.courseName);
    this.setData({
      Course: options.courseName,
      Teacher: options.teacherName,
    })

    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/searchComment',

      data: {
        CourseName: this.data.Course,
        TeacherName: this.data.Teacher,
      },
      success: function (res) {

        
          self.setData({
            items: res.data.data
          })
          
          console.log(res)

        
      }
    })
  },

onShow: function(){
  var self = this;
  wx.request({
    url: 'https://npswk7eu.qcloud.la/weapp/searchComment',

    data: {
      CourseName: this.data.Course,
      TeacherName: this.data.Teacher,
    },
    success: function (res) {


      self.setData({
        items: res.data.data
      })

      console.log(res)


    }
  })
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  // onReady () {

  // },

  /**
   * 生命周期函数--监听页面显示
   */
  /*onShow () {
    // 执行coolsite360交互组件展示
    app.coolsite360.onShow(this);
  },*/

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh () {
    
  },


  //以下为自定义点击事件
  
})


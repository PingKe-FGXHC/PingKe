const util = require('../../utils/util');
const app = getApp();

Page({

  data: {
    CourseName: '',
    TeacherName: '',
    UserName:'',
    // items: [
    //   {
    //     "url": "http://127.0.0.1/1.flv",
    //     "title": "这是标题一"
    //   },
    //   {
    //     "url": "http://127.0.0.1/2.flv",
    //     "title": "这是标题二"
    //   }
    // ]
    items:[{}],
    buttonName:'点赞'
  },
  onShow() {
    
  }, 
  // onLoad: function (options) {
  //   console.log(app.global.Data.username);
  //   if (app.globalData.username == 'admin') {
  //     this.setData({
  //       buttonName: '删除',
  //     })
  //   }
  // },

  clickToLike: function (e) {
    var self = this;
    var index = e.currentTarget.id;
    console.log(self.data.items[index].username);
    console.log(self.data.CourseName);
    console.log(self.data.TeacherName);
    if (app.globalData.username == 'admin'){
      wx.request({
        url: 'https://npswk7eu.qcloud.la/weapp/delete_comment',

        data: {
          CourseName: self.data.CourseName,
          TeacherName: self.data.TeacherName,
          UserName: self.data.items[index].username,
        },
        success: function (res) {
          console.log(res.data);
          self.setData({
            items: res.data.data
          })
        }
      })
      }
      else{
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/addLike',

      data: {
        CourseName: self.data.CourseName,
        TeacherName: self.data.TeacherName,
        UserName: self.data.items[index].username,
      },
      success: function (res) {
        console.log(res.data)
        self.setData({
          items: res.data.data
        })
      }
    })
    
    
  }
  },
  

  //   setTimeout(function () {
  //     self.setData({
  //       isBtnClicked: false
  //     });
  //   }, 1000);
  // },

      

  

  onLoad: function (options) {
    var self = this;
    this.setData({
      CourseName: options.CourseName,
      TeacherName: options.TeacherName,
      
    })
    if (app.globalData.username == 'admin') {
      this.setData({
        buttonName: '删除',
      })
      
    }
   
    wx.request({
      url: 'https://npswk7eu.qcloud.la/weapp/searchComment',

      data: {
        CourseName: this.data.CourseName,
        TeacherName: this.data.TeacherName,
        
      },
      success: function (res) {

        console.log(res.data)
        if (res.data.data.length == 0) {  //失败
          util.showModel('查询失败', '无此评论');
        }
        else {  //成功
          // item = self.data.item, index = 10;//n随意
          // item[index] = changedata;
          var i;
          self.setData({
            items: res.data.data
          })
          

        }
      }
    })

  }



})